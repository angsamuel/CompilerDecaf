python ../compile.py $1
