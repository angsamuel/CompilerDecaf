Project was created using python 2.7. Everything for part 2 should be working, although we didn't have a lot of test cases for error handling so there may be something I missed.
The directory workdir contains everything you need to run my code. Because the project is written in python you don't need to run build.sh, it's just an empty file.

To run a test and plop the results in some file, use exec.sh. Here is one example:

    ./exec.sh ../samples2/control.decaf > ../results/control.out
    
If you have problems running my code or need to get in contact, feel free to email me at samuel.ang.prog@gmail.com
